// export const api = "https://dull-gold-clam-tutu.cyclic.app"
export const api = "https://lostandfound-api.onrender.com";
// export const api = "http://localhost:8000";
// export const api = "https://lost-and-found-api-nine.vercel.app";
